Title: Newsletter Number X
Date: 12-9-2019 10:04am
Template: newsletter
URL: newsletter/issue-X.html
save_as: newsletter/issue-X.html

Welcome to the Xth edition of this newsletter. 

## Around the site

* [Combining Multiple Excel Worksheets Into a Single Pandas Dataframe](https://pbpython.com/pandas-excel-tabs.html)
  covers a simple approach to parse multiple excel tabs into one DataFrame. 

## Other news

* [Altair](https://altair-viz.github.io/index.html) just released a new version. If you haven't looked at it in a while,
  check out some of the [examples](https://altair-viz.github.io/gallery/index.html) for a snapshot of what you can do with it.

## Final Words

Thanks again for subscribing to the newsletter. Feel free to forward it on to others that may be interested.