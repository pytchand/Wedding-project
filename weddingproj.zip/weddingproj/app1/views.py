from django.shortcuts import render,redirect
from django.contrib.auth.forms import UserCreationForm,AuthenticationForm
from .forms import form,form1
from django.http import HttpResponse,HttpResponseRedirect
from .models import database
from django.contrib import messages
# Create your views here.
def homepage(request):
    if request.method =='POST':
        form = AuthenticationForm(data=request.POST)
        if form.is_valid():
            return redirect('items')


    
    else:
        form = AuthenticationForm()
    return render(request,'homepage.html',{'form':form})
    



def signup(request):
    if request.method == "POST":
        form = UserCreationForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect("homepage")
    else:
        form = UserCreationForm()
    return render(request,'signup.html',{'form':form})



def login(request):
    if request.method =='POST':
        form = AuthenticationForm(data=request.POST)
        if form.is_valid():
            return redirect('items')


    
    else:
        form = AuthenticationForm()
    return render(request,'loginpage.html',{'form':form})


def items(request):
    form2 = form()
    if request.method == 'POST':
        form1=form(request.POST)
        if form1.is_valid():
            form1.save()
            return redirect('items')
    else :
        form2=form()
        
    return render(request,'items.html',{'form':form2})


def orderpage(request):
    d = database.objects.all()
    return render(request,'order.html',{'database':d})


def edit(request,id):
    f=database.objects.get(id=id)
    form1=form()
    return render(request,"edit.html",{"editdata":f,"form":form1})


def update(request,id):
    update=database.objects.get(id=id)
    g=form(request.POST,instance=update)
    if g.is_valid():
        g.save()
        messages.success(request,"Data Updated Successfully")
        return render(request,"edit.html",{"editdata":update})
        
                      
    else:
        return render(request,"edit.html",{"editdata":update})
        
        

def delete(request,id):
    dele=database.objects.get(id=id)
    if request.method=='POST':
        dele.delete()
        return HttpResponseRedirect("http://127.0.0.1:8000/order/")
        
    return render(request,'delete.html',{"editdata":dele})

