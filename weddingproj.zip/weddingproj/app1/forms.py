from .models import database
from django import forms

class form(forms.ModelForm):
    class Meta:
        model=database
        fields=["Name","Address","pgift","pgift2","pgift3"]




DEMO_CHOICES =( 
    ("1", "Pendding"), 
    ("2", "Dispached"), 
    ("3", "Packing"), 
    ("4", "order conformed"),
    ("5", "arriving"),
)

class form1(forms.Form):
    class Meta:
        models=database
        status = forms.MultipleChoiceField(choices = DEMO_CHOICES)
        fields=["status"]




