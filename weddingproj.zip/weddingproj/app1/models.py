from django.db import models
from multiselectfield import MultiSelectField
from django import forms

# Create your models here.
class database(models.Model):
    Name=models.CharField(max_length=64,null=True,blank=True)
    Address=models.CharField(max_length=10000,null=True,blank=True)
    pgift=models.BooleanField(null=True,blank=True)
    pgift2=models.BooleanField(null=True,blank=True)
    pgift3=models.BooleanField(null=True,blank=True)
    status=models.CharField(max_length=65,null=True,blank=True)
    
