from datetime import datetime

from django.shortcuts import render

# Create your views here.
from rest_framework.response import Response
from rest_framework.views import APIView
from .models import UserVisit

class HelloWorld(APIView):
    """
    Basic 'Hello World' view. Show our current API version, and the current time
    """

    def get(self, request, format=None):
        data = {
            'version': 1.0,
            'time': datetime.now()
        }
        return Response(data)

