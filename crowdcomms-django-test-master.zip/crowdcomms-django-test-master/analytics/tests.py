from unittest import mock

from django.contrib.auth.models import User
from django.test import TestCase

# Create your tests here.
from rest_framework.test import APITestCase
import datetime

from analytics.models import UserVisit


class UserVisitLoggingTests(APITestCase):

    def test_helloworld_works(self):
        """
        We can make a basic request to /helloworld/
        """
        response = self.client.get('/helloworld/')
        assert response.data.get('version') == 1.0

    def test_helloworld_returns_the_current_time(self):
        """
        The /helloworld/ endpoint shows the current time
        """
        with mock.patch('analytics.views.datetime') as mock_datetime:
            mock_datetime.now.return_value = datetime.datetime(2018, 1, 1, 9)
            response = self.client.get('/helloworld/')
        self.assertEqual(response.data.get('time'), datetime.datetime(2018, 1, 1, 9))

    def test_helloworld_logs_last_logins(self):
        """
        When we visit /helloworld/ as a logged-in user, then the system logs a UserVisit for that us
        """
        user = User.objects.create_user(username='bob', password='bob')
        self.client.login(username='bob', password='bob')
        self.client.get('/helloworld/')
        self.assertEqual(UserVisit.objects.count(), 1)
        self.assertEqual(UserVisit.objects.first().user, user)

    def test_other_views_log_last_logins(self):
        """
        When we visit any other url as a logged in user, then a visit is also logged there
        """
        user = User.objects.create_user(username='bob', password='bob')
        self.client.login(username='bob', password='bob')
        self.client.get('/bunnies/')
        self.assertEqual(UserVisit.objects.count(), 1)
        self.assertEqual(UserVisit.objects.first().user, user)

    def test_only_one_UserVisit_created_per_user(self):
        '''
        Only one UserVisit is created for each user, but the time is updated
        '''
        user = User.objects.create_user(username='bob', password='bob')
        self.client.login(username='bob', password='bob')
        self.client.get('/bunnies/')
        self.assertEqual(UserVisit.objects.count(), 1)

        with mock.patch('django.utils.timezone') as mock_tz:
            mock_tz.return_value = datetime.datetime(2017, 1, 1, 9)
            self.client.get('/bunnies/')
        self.assertEqual(UserVisit.objects.count(), 1)
        visit = UserVisit.objects.get(user=user)

        assert visit.last_seen == datetime.datetime(2017, 1, 1, 9)




