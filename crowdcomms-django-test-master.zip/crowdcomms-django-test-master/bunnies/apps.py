from django.apps import AppConfig


class BunniesConfig(AppConfig):
    name = 'bunnies'
